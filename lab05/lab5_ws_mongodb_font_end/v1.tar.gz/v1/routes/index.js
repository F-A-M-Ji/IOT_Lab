var express = require('express');
var router = express.Router();

/* GET home page. */
router.get('/', function(req, res, next) {
  res.render('index', { title: 'Express' });
});

var waterlevel='FULL';
var LED="ON";
/* POST home page. */
router.post('/sendname', function(req, res, next) {
  console.log(req.body.name);
  console.log(req.body.surname);
  res.render('index', { title: 'OK' });
  
});


router.get('/getwaterlevel', function(req, res, next) {
  
  res.render('farmstatus', { Waterlevel: waterlevel});
  
});



router.post('/setled', function(req, res, next) {
  console.log(req.body.led);
  LED=req.body.led;
  res.render('index', { title: 'OK' });
  
});
router.get('/getLED', function(req, res, next) {
  
  res.status(200).json({ledstatus:LED});
  
});

router.post('/sendwaterlevel', function(req, res, next) {
  console.log(req.body.Waterlevel);
  waterlevel=req.body.Waterlevel;  //pi changes to "NOTFULL"
  res.sendStatus(200);  
});





module.exports = router;
